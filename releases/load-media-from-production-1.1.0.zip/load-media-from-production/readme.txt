=== Load Media From Production ===

Contributors: James Hunt
Tags: block
Requires at least: 5.0
Tested up to: 6.2.0
Stable tag: 1.1
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A super simple way to load your media files from another server. No need to copy or download gigabytes of media. Use on your local development or to quickly fire up staging area without duplicating thousands of media file. Designed to work with Lando and Patheon.

Description
===========================

Please see readme.md for full read me.

Instructions for Install
===========================

Download the plugin zip file.

Go to WordPress Admin > Plugins > Add New Plugin > Upload Plugin, and upload the plugin zip file.

There are other ways to install the plugin, please see the WordPress documentation - http://codex.wordpress.org/Managing_Plugins

Once installed, Activate the plugin.

Go to Settings > Load Media From Production to set the URL of your production WordPress install.
